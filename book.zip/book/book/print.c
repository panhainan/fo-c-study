#include<stdio.h>
test_print() {
	printf("sfdsdfsdfsd");
	printf("\n");
	printf("sdfd%afdasfd");
	printf("\n");
	printf("sdfd*sdfsdf");
	printf("\n");

}
test_sprint() {
	char s[64];
	sprintf(s,"%s","ni shi sha bi ye bao cuo a ");
	printf("%s\n",s);
}