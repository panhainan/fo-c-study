#include<stdio.h>
hello(){
	printf("hello, world!\n");
	printf("I'm Panhainan.F\cO\n");
	printf("hello, world!\b");//  \b ��ʾ���˷�
}