#include<stdio.h>
void print_i(int num) {
	printf("%d\n", num);
}
void print_l(long num) {
	printf("%ld\n", num);
}
void print_d(double num) {
	printf("%lf\n", num);
}
void print_f(float num) {
	printf("%f\n", num);
}
void print_c(char c) {
	printf("%c\n", c);
}
void print_s(char s) {
	printf("%s\n", s);
}